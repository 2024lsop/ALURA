// fantasia, aventura, drama

// a viagem de chihiro, LIVRE, fantasia, aventura
// guardiões da galáxia, 12, fantasia, aventura
// todos menos você, 16, comédia, romance
// a sociedade da neve, 14, drama, aventura, história
// interstellar, 10, aventura, drama, ficção científica
// la la land, LIVRE, musical, drama, romance, comédia 


function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}

let campoIdade;

function setup() {
  createCanvas(400, 400);
  campoIdade = createInput("5");
}

function draw() {
  background(220);
  let idade = campoIdade.value();
  let recomendacao = geraRecomendacao(idade);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade) {
  if(idade >= 10) {
    if(idade >= 14) {
      return "todos menos você";
    } else {
      return "a sociedade da neve";
    }
  } else {
    return "interstellar";
  }
}